from setuptools import setup

setup(
    name='Cyber-Sploit',
    version='1.0',
    packages=[''],
    url='https://github.com/Cyber-Dioxide/Cyber-Sploit',
    license='MIT',
    author='Cyber-Dioxide',
    author_email='cyberdioxide@duck.com',
    description='Installation'
)
