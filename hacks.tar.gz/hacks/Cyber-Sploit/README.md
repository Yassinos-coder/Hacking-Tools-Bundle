# Cyber-Sploit
A framework like a metasploit containg a variety of modules for pentesting or ethical hacking. This repo willl be updated and new modules will be added time to time. This framwork is still under development phase. Those who are intrested for adding new modules can contribute. Mostly modules are written in Python, others may be aded with time (Ruby,  GoLang).
![Screenshot_20220826_224824](https://user-images.githubusercontent.com/93708296/186963364-54cee1a8-1e40-47e8-929c-8941e597a068.png)

![Screenshot_20220826_224625](https://user-images.githubusercontent.com/93708296/186963396-e8b1c9e6-5da9-4158-8c45-dcfc75904be6.png)



# Root
Better to root the terminal in order to avoid errors.

# Usage
>* git clone https://github.com/Cyber-Dioxide
>* change directory
>* chmod +x *
>* bash install.sh
>* ./Cyber-Sploit.py

# YouTube
* Will soon available once the code is tested

# Commands:
>- [ TIME ]/ help                                                      =>                      #Will show all the available commands
>- [ TIME ]/ show modules                                              =>                      #Will show available modules with description
>- [ TIME ]/ use <modules_name.py>                                     =>                      #Selects handle-backdoor.py module
>- [ TIME ]/handle-backdoor.py/ info                                   =>                      #To view to information of the selected module
>- [ TIME ]/handle-backdoor.py/ options                                =>                      #To see all the required parameters
>- [ TIME ]/handle-backdoor.py/ set <variable> <value>                 =>                      #Sets the value of a parameter
>- [ TIME ]/handle-backdoor.py/ set lhost 127.0.0.1                    =>                      #Vairabe=lhost , Value=127.0.0.1
>- [ TIME ]/handle-backdor.py/ run                                     =>                      #Starts the selected module.
>- [ TIME ]/handle-backdoor.py/ back                                   =>                      #Unselects the selected module
>- [ TIME ]/ banner                                                    =>                      #Displays a random banner
>- [ TIME ]/ exit #You've guessed it!
![Screenshot_20220824_152640](https://user-images.githubusercontent.com/93708296/186955768-4b47f7d2-5a7b-4157-a108-a9791e365b61.png)
![Screenshot_20220826_224853](https://user-images.githubusercontent.com/93708296/186963463-2f5721b9-974c-4364-bb85-fcf8f0f4d126.png)


* More options and modules will be added
* Set all parameters carefully, once you've type "run", all the setted parameters will be deleted and you will have to set the again for that module
* Root your terinal
![Screenshot_20220824_152717](https://user-images.githubusercontent.com/93708296/186955856-6d221fb1-74ae-4288-87a8-7fab61568f4b.png)

# STAR
Give a star if you liked it

# Installation
> bash install.sh

Will install all the required packages.

# Raspberry pi
Anyone having an extra raspberry 4 can donate it to your brother/son (ME) (+_+). I'LL be thankfull for this kindness

# Contribute
If someone wants to contribute, warmly welcommed.
* Instagram: @cyber_dioxide

# More
The reason for adding timestamp is that it took alot of time developed. I had to switch my Laptop to Linux as a primary OS because VB was no more responding (-_-).

# Paypal
@maazwaheed123

# Help/Support
For any help/support, iam mostly active on Instagram @cyber_dioxide , @coding_memz

# Screenshots++
![Screenshot_20220826_221405](https://user-images.githubusercontent.com/93708296/186958570-e6ed55c1-f860-4d30-8469-249e677c9ddc.png)

![Screenshot_20220826_224701](https://user-images.githubusercontent.com/93708296/186965749-fa426716-f822-4beb-abe1-d2b8d94daa14.png)




