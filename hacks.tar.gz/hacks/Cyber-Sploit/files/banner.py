
from files.colors import text_color ,  bg_color
from files.logos import render
import datetime

def dt():
    return datetime.datetime.now().strftime("%H:%M:%S")
















