use warnings FATAL => 'all';
use strict;
system("color 03");
system("Loading...");
system("netstat -r > /dev/null > nets.txt");
# system("py -3 check.py nets.txt");
# system("netstat -a > /dev/null > nets.txt");
# system("py -3 check.py nets.txt");
# system("py -3 clear.py nets.txt");
# system("Core/press");
#
# # system("")