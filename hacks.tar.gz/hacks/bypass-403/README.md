# Bypass-403
- A simple script just made for self use for bypassing 403
- It can also be used to compare responses on verious conditions as shown in the below snap
![](responses.jpg)

# Usage
`./bypass-403.sh https://example.com admin`

`./bypass-403.sh website-here path-here`

# Features
- Use 24 known Bypasses for 403 with the help of curl

# Installation
   * `git clone https://github.com/iamj0ker/bypass-403`
   * `cd bypass-403`
   * `chmod +x bypass-403.sh`
   * `sudo apt install figlet`  - If you are unable to see the logo as in the screenshot
   
# Contributers
  [remonsec](https://github.com/remonsec),
  [manpreet](https://github.com/manpreet406)
  [MayankPandey01](https://github.com/MayankPandey01)
  [saadibabar](https://github.com/saadibabar)
