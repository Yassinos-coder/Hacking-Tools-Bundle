[![GitHub Repo Size](https://img.shields.io/github/languages/code-size/giovanni-iannaccone/ians)](https://github.com/giovanni-iannaccone/ians)
[![GitHub Issues](https://img.shields.io/bitbucket/issues-raw/giovanni-iannaccone/ians)](https://github.com/giovanni-iannaccone/ians)
[![GitHub Supported Os](https://img.shields.io/badge/OS-linux-blue)](https://github.com/giovanni-iannaccone/ians)

![view](https://user-images.githubusercontent.com/80602545/184477861-2b047baa-d321-4ade-b22a-769642ff5d4f.jpg)

# ENGLISH

Hi, I'm Giovanni Iannaccone and when I wrote this tool (2022) I was 15 years old. I took part of the code from books/blog and I riadapted it especially for this tool. You have certainly noticed that it has 9 manner: port scanning, sniffing, DDos attacks, ARP poisoning, bruteforce, trojan creation, chat room ssh, site mapper and username finder. Obviously everything is open source and you can modify the code based on your needs, I tryed to make it the more complete I could hope you'll like it and it will be useful.
To start it you have to type the following commands:
```
git clone https://github.com/giovanni-iannaccone/ians
```
```
cd ians
```
```
cd bash_file
```
```
chmod +x install.sh
```
```
./install.sh
```
```
cd ../code
```
```
sudo python3 ians.py
```

Don't lost any update: https://github.com/giovanni-iannaccone/ians
OBVIOUSLY EVERYTHING IS WRITTEN FOR EDUCATIONAL PURPOSE, THE USER KNOW WHAT HE IS DOING AND THE AUTHOR IS NOT RESPONSIBLE FOR ANY ILLEGAL USE OF THIS TOOL


# ITALIANO 

Ciao, mi chiamo Giovanni Iannaccone e quando scrissi questo tool (2022) avevo 15 anni. Parte del codice non l'ho scritta io, ma l'ho presa da libri/blog e poi riadattata appositamente per funzionare su questo tool. Come avete sicuramente notato ha 9 modalità: port scanning, sniffing, attacchi DDos, ARP poisoning bruteforce, creazione di trojan, creazione di una chat room ssh, mappatura di siti e ricerce di username. Ovviamente il tutto è open source e potete modificare il codice a seconda delle vostre esigenze, io ho cercato di renderlo il più completo possibile. Spero vi piaccia e vi sia utile.
Per avviarlo dovrete digitare i seguenti comandi:
```
git clone https://github.com/giovanni-iannaccone/ians
```
```
cd ians
```
```
cd bash_file
```
```
chmod +x install.sh
```
```
./install.sh
```
```
cd ../code
```
```
sudo python3 ians.py
```

Non perdete aggiornamenti: https://github.com/giovanni-iannaccone/ians
OVVIAMENTE IL TUTTO È SCRITTO PER PURO SCOPO EDUCATIVO, L'UTENTE SA A COSA VA INCONTRO E L'AUTORE NON SI ASSUME ALCUNA RESPONSABILITÀ PER USI ILLEGALI DEL TOOL


<div id="header" align="center">
  <img src="https://media.giphy.com/media/YRMb6dd7zprS00JdGZ/giphy.gif" width="100"/>
</div>
