apt-get update && upgrade
pkg install python
pkg install python3
echo " requirements installed sucessfully !! "
