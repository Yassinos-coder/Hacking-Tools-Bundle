sudo apt-get  update && upgrade
sudo apt-get  install python
sudo apt-get  install python3 
echo " requirements installed sucessfully !! "
