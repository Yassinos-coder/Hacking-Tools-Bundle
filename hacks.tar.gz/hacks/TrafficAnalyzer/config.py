mysql_settings = {
    "host": "35.157.16.43",
    "user": "sql11517662",
    "password": "M5nqmGyiHW",
    "database": "sql11517662",
    "port": "3306"
}

interface = "eth0"
tcp_timeout = 600
udp_timeout = 600
app_timeout = 500
